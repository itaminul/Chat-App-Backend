module.exports = (io, socket, prisma) => {
    const updateUserStatus = async (userId, isActive) => {
      await prisma.user.update({
        where: { id: userId },
        data: { isActive },
      });
      io.emit('user_status_change', { userId, isActive });
    };
  
    socket.on('join_group', async (groupId) => {
      socket.join(`group_${groupId}`);
      console.log(`User ${socket.user.id} joined group ${groupId}`);
    });
  
    socket.on('leave_group', async (groupId) => {
      socket.leave(`group_${groupId}`);
      console.log(`User ${socket.user.id} left group ${groupId}`);
    });
  
    socket.on('send_message', async ({ groupId, content }) => {
      try {
        const message = await prisma.message.create({
          data: {
            content,
            userId: socket.user.id,
            groupId,
          },
          include: { user: { select: { id: true, username: true } } },
        });
        io.to(`group_${groupId}`).emit('new_message', message);
      } catch (error) {
        console.error('Error sending message:', error);
      }
    });
  
    socket.on('disconnect', async () => {
      await updateUserStatus(socket.user.id, false);
      console.log(`User ${socket.user.id} disconnected`);
    });
  
    // Set user as active when they connect
    updateUserStatus(socket.user.id, true);
  };