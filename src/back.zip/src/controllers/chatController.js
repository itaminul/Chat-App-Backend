const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

exports.createGroup = async (req, res) => {
  try {
    const { name } = req.body;
    const userId = req.user.id;
    const group = await prisma.group.create({
      data: {
        name,
        members: {
          connect: { id: userId },
        },
      },
    });
    res.status(201).json(group);
  } catch (error) {
    res.status(500).json({ error: 'Error creating group' });
  }
};

exports.getGroups = async (req, res) => {
  try {
    const userId = req.user.id;
    const groups = await prisma.group.findMany({
      where: {
        members: {
          some: {
            id: userId,
          },
        },
      },
    });
    res.json(groups);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching groups' });
  }
};

exports.getGroupMessages = async (req, res) => {
  try {
    const { groupId } = req.params;
    const messages = await prisma.message.findMany({
      where: { groupId: parseInt(groupId) },
      include: { user: { select: { id: true, username: true } } },
      orderBy: { createdAt: 'asc' },
    });
    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching messages' });
  }
};