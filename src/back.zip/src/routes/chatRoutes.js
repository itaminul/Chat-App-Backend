const express = require('express');
const chatController = require('../controllers/chatController');
const authMiddleware = require('../middlewares/authMiddleware');

const router = express.Router();

router.use(authMiddleware);

router.post('/groups', chatController.createGroup);
router.get('/groups', chatController.getGroups);
router.get('/groups/:groupId/messages', chatController.getGroupMessages);

module.exports = router;